package Assignment2;

public class CustomException extends Exception{
    public CustomException(String msg)
    {
        super(msg);
    }



}
